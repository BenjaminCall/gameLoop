I am using lodash as a resource and importing that in <script> in my html.
Meaning that if not connected to the internet it will not work.

Thanks.